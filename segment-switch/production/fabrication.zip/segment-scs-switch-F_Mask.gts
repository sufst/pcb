G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,9.0.4*
G04 #@! TF.CreationDate,2026-03-28T14:19:25+00:00*
G04 #@! TF.ProjectId,segment-scs-switch,7365676d-656e-4742-9d73-63732d737769,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 9.0.4) date 2026-03-28 14:19:25*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 Aperture macros list*
%AMRoundRect*
0 Rectangle with rounded corners*
0 $1 Rounding radius*
0 $2 $3 $4 $5 $6 $7 $8 $9 X,Y pos of 4 corners*
0 Add a 4 corners polygon primitive as box body*
4,1,4,$2,$3,$4,$5,$6,$7,$8,$9,$2,$3,0*
0 Add four circle primitives for the rounded corners*
1,1,$1+$1,$2,$3*
1,1,$1+$1,$4,$5*
1,1,$1+$1,$6,$7*
1,1,$1+$1,$8,$9*
0 Add four rect primitives between the rounded corners*
20,1,$1+$1,$2,$3,$4,$5,0*
20,1,$1+$1,$4,$5,$6,$7,0*
20,1,$1+$1,$6,$7,$8,$9,0*
20,1,$1+$1,$8,$9,$2,$3,0*%
G04 Aperture macros list end*
%ADD10C,3.200000*%
%ADD11RoundRect,0.400000X-0.400000X2.100000X-0.400000X-2.100000X0.400000X-2.100000X0.400000X2.100000X0*%
%ADD12R,1.100000X1.500000*%
G04 APERTURE END LIST*
D10*
G04 #@! TO.C,H2*
X139000000Y-96325000D03*
G04 #@! TD*
G04 #@! TO.C,H1*
X126000000Y-96325000D03*
G04 #@! TD*
D11*
G04 #@! TO.C,J1*
X133750000Y-96325000D03*
X131250000Y-96325000D03*
G04 #@! TD*
D12*
G04 #@! TO.C,SW1*
X131230000Y-91950000D03*
X133770000Y-91950000D03*
X131230000Y-83050000D03*
X133770000Y-83050000D03*
G04 #@! TD*
M02*
